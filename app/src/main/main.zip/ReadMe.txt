External dependencies used :

For image Loading - com.squareup.picasso:picasso:2.5.2 - http://repo1.maven.org/maven2/com/squareup/picasso/picasso/2.5.2/picasso-2.5.2.jar
For converting the Json the Class model - com.google.code.gson:gson:2.8.0  - http://repo1.maven.org/maven2/com/google/code/gson/gson/2.8.0/

Learn coding from 
Udacity - https://classroom.udacity.com/courses/ud853/lessons/1395568821/concepts/36148286800923
Lynda Videos.

Other than using the picasso and gson, I wrote the code from the scratch seeing the videos. None copied from a downloaded project. Just few codes from stackoverflow taken.

